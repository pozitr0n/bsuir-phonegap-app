package org.apache.cordova;

@Deprecated
public class DroidGap
  extends CordovaActivity
{}


/* Location:           C:\Users\user\Desktop\Decompiling of the PhoneGap App\Decompiling\iSport-v.0.1_dex2jar.jar
 * Qualified Name:     org.apache.cordova.DroidGap
 * JD-Core Version:    0.7.0.1
 */