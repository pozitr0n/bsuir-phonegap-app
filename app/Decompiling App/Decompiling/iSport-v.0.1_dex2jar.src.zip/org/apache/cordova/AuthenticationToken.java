package org.apache.cordova;

public class AuthenticationToken
{
  private String password;
  private String userName;
  
  public String getPassword()
  {
    return this.password;
  }
  
  public String getUserName()
  {
    return this.userName;
  }
  
  public void setPassword(String paramString)
  {
    this.password = paramString;
  }
  
  public void setUserName(String paramString)
  {
    this.userName = paramString;
  }
}


/* Location:           C:\Users\user\Desktop\Decompiling of the PhoneGap App\Decompiling\iSport-v.0.1_dex2jar.jar
 * Qualified Name:     org.apache.cordova.AuthenticationToken
 * JD-Core Version:    0.7.0.1
 */