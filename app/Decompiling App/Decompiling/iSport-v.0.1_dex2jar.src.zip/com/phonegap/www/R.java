

R

  attr {}
  
  drawable
  
    icon = 2130837504
  
  
  string
  
    app_name = 2130968576
  
  
  xml
  
    config = 2130903040
  



/* Location:           C:\Users\user\Desktop\Decompiling of the PhoneGap App\Decompiling\iSport-v.0.1_dex2jar.jar
 * Qualified Name:     com.phonegap.www.R
 * JD-Core Version:    0.7.0.1
 */