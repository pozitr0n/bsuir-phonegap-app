

BuildConfig

  DEBUG = 



/* Location:           C:\Users\user\Desktop\Decompiling of the PhoneGap App\Decompiling\iSport-v.0.1_dex2jar.jar
 * Qualified Name:     com.phonegap.www.BuildConfig
 * JD-Core Version:    0.7.0.1
 */